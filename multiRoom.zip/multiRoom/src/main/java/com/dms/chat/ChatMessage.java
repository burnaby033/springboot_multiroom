package com.dms.chat;

public class ChatMessage {
    String chatRoomId;
    String message;
    String type;
    
	public String getChatRoomId() {
		return chatRoomId;
	}
	public String getMessage() {
		return message;
	}
	public String getType() {
		return type;
	}
     
}
